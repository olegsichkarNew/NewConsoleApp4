using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace AstroSwissEph
{
    public static class Exporters
    {
        /// <summary>Exports periods to a compact CSV: StartUtc, EndUtc, DurationHours, Bodies, Mode, OrbDeg</summary>
        public static void ExportPeriodsCsv(string path, IReadOnlyList<Period> periods, SearchRequest req, string modeName)
        {
            var sb = new StringBuilder();
            sb.AppendLine("StartUtc,EndUtc,DurationHours,Bodies,Mode,OrbDeg,Samples");

            foreach (var p in periods)
            {
                var durH = (p.EndUtc - p.StartUtc).TotalHours;
                var bodies = string.Join("+", req.Bodies);
                sb.AppendLine($"{p.StartUtc:O},{p.EndUtc:O},{durH.ToString("0.###", CultureInfo.InvariantCulture)},{bodies},{modeName},{req.DiffDeg.ToString(CultureInfo.InvariantCulture)},{p.Samples.Count}");
            }

            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }

        /// <summary>Exports detailed samples (each hit) to CSV for debugging.</summary>
        public static void ExportHitsCsv(string path, IReadOnlyList<Period> periods, SearchRequest req)
        {
            var sb = new StringBuilder();
            sb.Append("TimeUtc");
            foreach (var b in req.Bodies)
                sb.Append($",Lon_{b},Speed_{b},Sign_{b},DegInSign_{b}");
            sb.AppendLine();

            foreach (var p in periods)
            foreach (var h in p.Samples)
            {
                sb.Append(h.TimeUtc.ToString("O"));

                foreach (var b in req.Bodies)
                {
                    var s = h.Bodies[b];
                    sb.Append($",{s.LonDeg.ToString(CultureInfo.InvariantCulture)}");
                    sb.Append($",{s.SpeedDegPerDay.ToString(CultureInfo.InvariantCulture)}");
                    sb.Append($",{s.ZodiacSign}");
                    sb.Append($",{s.DegreeInSign.ToString(CultureInfo.InvariantCulture)}");
                }

                sb.AppendLine();
            }

            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }
    }
}
